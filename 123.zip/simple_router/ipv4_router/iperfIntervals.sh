#!/bin/bash


echo "running 1st test"
iperf -c $1 -t 15 -u
echo "sleeping"
sleep 15
echo "running 2nd test"
iperf -c $1 -t 15 -u
echo "sleeping"
sleep 20
echo "running 3rd test"
iperf -c $1 -t 15 -u
echo "sleeping"
sleep 25
echo "running 4th test"
iperf -c $1 -t 15 -u

echo "stress test complete"
